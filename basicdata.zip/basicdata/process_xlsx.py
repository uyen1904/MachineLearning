import pandas as pd

dataframe=pd.read_excel("../dataset/SalesTransactions/SalesTransactions.xlsx")

print(dataframe)